import os
import re
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, TIT2, TALB, TPE1, TDRC, TRCK

music_root = r"\\TRUENAS\Film\Far-Sange"

# Dato-mønstre
DATE_PAT = re.compile(r"^(\d{2})-(\d{2})-(\d{4})$")  # DD-MM-YYYY
TIME_PAT = re.compile(r"^(\d{2})-(\d{2})-(\d{2})$")  # HH-MM-SS


def uninvert_datetime(inv_dt):
    """Konverterer inverteret dato tilbage til ISO: 5975-96-77_85-04-42 → 2024-03-22_14-55-17"""
    date_part, time_part = inv_dt.split("_")
    iy, im, id_ = date_part.split("-")
    ih, imi, is_ = time_part.split("-")
    yyyy = str(9999 - int(iy)).zfill(4)
    mm   = str(99 - int(im)).zfill(2)
    dd   = str(99 - int(id_)).zfill(2)
    hh   = str(99 - int(ih)).zfill(2)
    mi   = str(99 - int(imi)).zfill(2)
    ss   = str(99 - int(is_)).zfill(2)
    return f"{yyyy}-{mm}-{dd}_{hh}-{mi}-{ss}"


# Inverteret format: 4 cifre - 2 cifre - 2 cifre (år kan være 5975 osv.)
INV_DATE_PAT = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")


def parse_filename(filename):
    """
    Returnerer (title, iso_datetime) eller None.
    iso_datetime format: YYYY-MM-DD_HH-MM-SS

    Understøtter:
      - Allerede omdøbt: IYYY-IMM-IDD_IHH-IMI-ISS_Titel  (inverteret)
      - Nyt:             DD-MM-YYYY_HH-MM-SS_Titel
      - Gammelt:         Titel_DD-MM-YYYY_HH-MM-SS
    """
    basename = os.path.splitext(filename)[0]
    parts = basename.split("_")

    if len(parts) < 3:
        return None

    # Allerede omdøbt (inverteret format): første segment har 4-cifret år (fx 5975)
    m_inv = INV_DATE_PAT.match(parts[0])
    m_time = TIME_PAT.match(parts[1]) if len(parts) > 1 else None
    if m_inv and m_time and int(m_inv.group(1)) > 2100:  # inverterede år er altid > 2100
        inv_dt = f"{parts[0]}_{parts[1]}"
        iso_dt = uninvert_datetime(inv_dt)
        title = "_".join(parts[2:]).strip()
        if not title:
            return None
        return title, iso_dt

    # Nyt format: første segment er DD-MM-YYYY
    m_date = DATE_PAT.match(parts[0])
    m_time = TIME_PAT.match(parts[1]) if len(parts) > 1 else None
    if m_date and m_time:
        day, month, year = m_date.group(1), m_date.group(2), m_date.group(3)
        hh, mm, ss = m_time.group(1), m_time.group(2), m_time.group(3)
        title = "_".join(parts[2:]).strip()
        if not title:
            return None
        iso_dt = f"{year}-{month}-{day}_{hh}-{mm}-{ss}"
        return title, iso_dt

    # Gammelt format: næstsidste segment er dato, sidste er tid
    m_date = DATE_PAT.match(parts[-2]) if len(parts) >= 2 else None
    m_time = TIME_PAT.match(parts[-1])
    if m_date and m_time:
        day, month, year = m_date.group(1), m_date.group(2), m_date.group(3)
        hh, mm, ss = m_time.group(1), m_time.group(2), m_time.group(3)
        title = "_".join(parts[:-2]).strip()
        if not title:
            return None
        iso_dt = f"{year}-{month}-{day}_{hh}-{mm}-{ss}"
        return title, iso_dt

    return None


def invert_datetime(iso_dt):
    """
    Inverterer dato+tid så nyeste sorterer først alfabetisk.
    Eks: 2024-03-22_14-55-17 → 5975-96-77_85-44-82
    """
    date_part, time_part = iso_dt.split("_")
    yyyy, mm, dd = date_part.split("-")
    hh, mi, ss = time_part.split("-")

    inv_yyyy = str(9999 - int(yyyy)).zfill(4)
    inv_mm   = str(99 - int(mm)).zfill(2)
    inv_dd   = str(99 - int(dd)).zfill(2)
    inv_hh   = str(99 - int(hh)).zfill(2)
    inv_mi   = str(99 - int(mi)).zfill(2)
    inv_ss   = str(99 - int(ss)).zfill(2)

    return f"{inv_yyyy}-{inv_mm}-{inv_dd}_{inv_hh}-{inv_mi}-{inv_ss}"


skipped = []

for folder in sorted(os.listdir(music_root)):
    folder_path = os.path.join(music_root, folder)
    if not os.path.isdir(folder_path):
        continue

    # Saml alle parseable filer
    songs = []
    for filename in os.listdir(folder_path):
        if not filename.endswith(".mp3"):
            continue
        result = parse_filename(filename)
        if result is None:
            print(f"⚠ SKIP {folder}/{filename}")
            skipped.append(f"{folder}/{filename}")
            continue
        title, iso_dt = result
        songs.append((filename, title, iso_dt))

    # Sortér nyeste først for tracknumre
    songs.sort(key=lambda x: x[2], reverse=True)
    total = len(songs)

    for track_num, (filename, title, iso_dt) in enumerate(songs, start=1):
        filepath = os.path.join(folder_path, filename)

        # Byg nyt filnavn: INVDATO_INVTID_Titel.mp3
        inv = invert_datetime(iso_dt)
        new_filename = f"{inv}_{title}.mp3"
        new_filepath = os.path.join(folder_path, new_filename)

        # Omdøb filen hvis nødvendigt
        if filename != new_filename:
            try:
                os.rename(filepath, new_filepath)
                filepath = new_filepath
            except Exception as e:
                print(f"✗ Omdøbning fejlede {folder}/{filename} → {e}")
                continue

        # Sæt tags
        date_only = iso_dt[:10]  # YYYY-MM-DD til TDRC
        try:
            audio = MP3(filepath, ID3=ID3)
            if audio.tags is None:
                audio.add_tags()
            audio.tags["TIT2"] = TIT2(encoding=3, text=title)
            audio.tags["TALB"] = TALB(encoding=3, text=folder)
            audio.tags["TPE1"] = TPE1(encoding=3, text="Far")
            audio.tags["TDRC"] = TDRC(encoding=3, text=date_only)
            audio.tags["TRCK"] = TRCK(encoding=3, text=f"{track_num}/{total}")
            audio.save()
            print(f"✓ [{track_num}/{total}] {folder}/{new_filename} → '{title}' ({date_only})")
        except Exception as e:
            print(f"✗ Tags fejlede {folder}/{new_filename} → {e}")

print(f"\n--- Færdig ---")
if skipped:
    print(f"Skippet {len(skipped)} filer der ikke kunne parses:")
    for s in skipped:
        print(f"  {s}")
