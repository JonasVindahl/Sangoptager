import sys
import os
import re
import glob
import datetime
import shutil
import subprocess
import threading
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QStatusBar,
    QMessageBox, QVBoxLayout, QWidget, QDialog, QLabel, QInputDialog
)
from PyQt5.QtCore import Qt, QPoint, pyqtSignal, QObject
import obswebsocket
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, TIT2, TALB, TPE1, TDRC, TRCK


FFMPEG_PATH = r"C:\Users\jonas\Documents\ShareX\Tools\ffmpeg.exe"

# ── Dato/tid helpers ─────────────────────────────────────────────────────────

DATE_PAT = re.compile(r"^(\d{2})-(\d{2})-(\d{4})$")   # DD-MM-YYYY
TIME_PAT = re.compile(r"^(\d{2})-(\d{2})-(\d{2})$")   # HH-MM-SS
INV_PAT  = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")   # inverteret (år > 2100)


def invert_datetime(iso_dt):
    """2024-03-22_14-55-17 → 5975-96-77_85-44-82"""
    date_part, time_part = iso_dt.split("_")
    yyyy, mm, dd = date_part.split("-")
    hh, mi, ss   = time_part.split("-")
    return (
        f"{str(9999-int(yyyy)).zfill(4)}-{str(99-int(mm)).zfill(2)}-{str(99-int(dd)).zfill(2)}"
        f"_{str(99-int(hh)).zfill(2)}-{str(99-int(mi)).zfill(2)}-{str(99-int(ss)).zfill(2)}"
    )


def uninvert_datetime(inv_dt):
    """5975-96-77_85-44-82 → 2024-03-22_14-55-17"""
    date_part, time_part = inv_dt.split("_")
    iy, im, id_ = date_part.split("-")
    ih, imi, is_ = time_part.split("-")
    return (
        f"{str(9999-int(iy)).zfill(4)}-{str(99-int(im)).zfill(2)}-{str(99-int(id_)).zfill(2)}"
        f"_{str(99-int(ih)).zfill(2)}-{str(99-int(imi)).zfill(2)}-{str(99-int(is_)).zfill(2)}"
    )


def parse_filename(filename):
    """
    Returnerer (title, iso_datetime) eller None.
    Understøtter:
      - Inverteret:  IYYY-IMM-IDD_IHH-IMI-ISS_Titel
      - Nyt:         DD-MM-YYYY_HH-MM-SS_Titel
      - Gammelt:     Titel_DD-MM-YYYY_HH-MM-SS
    """
    basename = os.path.splitext(filename)[0]
    parts    = basename.split("_")

    if len(parts) < 3:
        return None

    # Inverteret format (år > 2100)
    m = INV_PAT.match(parts[0])
    if m and TIME_PAT.match(parts[1]) and int(m.group(1)) > 2100:
        iso_dt = uninvert_datetime(f"{parts[0]}_{parts[1]}")
        title  = "_".join(parts[2:]).strip()
        return (title, iso_dt) if title else None

    # Nyt format: DD-MM-YYYY_HH-MM-SS_Titel
    m = DATE_PAT.match(parts[0])
    if m and TIME_PAT.match(parts[1]):
        day, month, year = m.group(1), m.group(2), m.group(3)
        hh, mi, ss = parts[1].split("-")
        title = "_".join(parts[2:]).strip()
        return (title, f"{year}-{month}-{day}_{hh}-{mi}-{ss}") if title else None

    # Gammelt format: Titel_DD-MM-YYYY_HH-MM-SS
    m = DATE_PAT.match(parts[-2]) if len(parts) >= 3 else None
    if m and TIME_PAT.match(parts[-1]):
        day, month, year = m.group(1), m.group(2), m.group(3)
        hh, mi, ss = parts[-1].split("-")
        title = "_".join(parts[:-2]).strip()
        return (title, f"{year}-{month}-{day}_{hh}-{mi}-{ss}") if title else None

    return None


def retag_folder(folder_path, album_name):
    """Omdøb + sæt alle tags + genberegn TRCK for hele mappen. Nyeste = track 1."""
    songs = []
    for filename in os.listdir(folder_path):
        if not filename.endswith(".mp3"):
            continue
        result = parse_filename(filename)
        if result is None:
            continue
        title, iso_dt = result
        songs.append((filename, title, iso_dt))

    songs.sort(key=lambda x: x[2], reverse=True)
    total = len(songs)

    for track_num, (filename, title, iso_dt) in enumerate(songs, start=1):
        filepath = os.path.join(folder_path, filename)

        # Omdøb til inverteret format hvis nødvendigt
        inv          = invert_datetime(iso_dt)
        new_filename = f"{inv}_{title}.mp3"
        new_filepath = os.path.join(folder_path, new_filename)
        if filename != new_filename:
            try:
                os.rename(filepath, new_filepath)
                filepath = new_filepath
            except Exception:
                continue

        # Sæt alle tags
        date_only = iso_dt[:10]
        try:
            audio = MP3(filepath, ID3=ID3)
            if audio.tags is None:
                audio.add_tags()
            audio.tags["TIT2"] = TIT2(encoding=3, text=title)
            audio.tags["TALB"] = TALB(encoding=3, text=album_name)
            audio.tags["TPE1"] = TPE1(encoding=3, text="Far")
            audio.tags["TDRC"] = TDRC(encoding=3, text=date_only)
            audio.tags["TRCK"] = TRCK(encoding=3, text=f"{track_num}/{total}")
            audio.save()
        except Exception:
            pass

    return total


# ── OBS/fil helpers ───────────────────────────────────────────────────────────

def get_latest_recording_file(directory, ext="mp4"):
    files = glob.glob(os.path.join(directory, f"*.{ext}"))
    return max(files, key=os.path.getctime) if files else None


def convert_mp4_to_mp3(mp4_path):
    mp3_path = os.path.splitext(mp4_path)[0] + ".mp3"
    cmd = [
        FFMPEG_PATH,
        "-y", "-i", mp4_path,
        "-vn", "-acodec", "libmp3lame", "-b:a", "320k",
        mp3_path
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return mp3_path
    except subprocess.CalledProcessError:
        return None


def rename_latest_recording(new_name, directory, ext="mp4"):
    latest = get_latest_recording_file(directory, ext)
    if not latest:
        return None
    timestamp    = datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
    new_filename = f"{timestamp}_{new_name}.{ext}"
    new_path     = os.path.join(directory, new_filename)
    os.rename(latest, new_path)
    return new_path


def delete_latest_recording(directory, ext="mp4"):
    latest = get_latest_recording_file(directory, ext)
    if not latest:
        return False, "No file to delete."
    try:
        os.remove(latest)
        return True, f"Deleted {latest}"
    except Exception as e:
        return False, f"Error deleting: {e}"


# ── Background worker ─────────────────────────────────────────────────────────

class Worker(QObject):
    finished = pyqtSignal(str)   # besked når færdig
    error    = pyqtSignal(str)   # besked ved fejl

    def __init__(self, source_dir, target_dir):
        super().__init__()
        self.source_dir = source_dir
        self.target_dir = target_dir

    def run(self):
        try:
            mp4_file = get_latest_recording_file(self.source_dir, "mp4")
            if not mp4_file:
                self.error.emit("Ingen optagelse fundet.")
                return

            mp3_file = convert_mp4_to_mp3(mp4_file)
            if not mp3_file or not os.path.exists(mp3_file):
                self.error.emit("Fejl ved konvertering til MP3.")
                return

            album       = datetime.datetime.now().strftime("%Y-%m")
            dest_folder = os.path.join(self.target_dir, album)
            os.makedirs(dest_folder, exist_ok=True)
            dest_path   = os.path.join(dest_folder, os.path.basename(mp3_file))

            shutil.move(mp3_file, dest_path)
            os.remove(mp4_file)

            total = retag_folder(dest_folder, album)
            self.finished.emit(f"✓ Gemt — {total} sange i {album}")

        except Exception as e:
            self.error.emit(f"Fejl: {e}")


# ── UI ────────────────────────────────────────────────────────────────────────

class RenameOrDeleteDialog(QDialog):
    def __init__(self, source_dir, nextcloud_dir, status_callback):
        super().__init__()
        self.source_dir       = source_dir
        self.nextcloud_dir    = nextcloud_dir
        self.status_callback  = status_callback
        self.deleted          = False
        self.initUI()

    def initUI(self):
        self.resize(250, 125)
        self.setWindowTitle("Post-Recording Options")
        self.setWindowModality(Qt.ApplicationModal)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Vælg handling for seneste optagelse:", self))

        btn_r = QPushButton("Rename", self)
        btn_r.clicked.connect(self.do_rename)
        layout.addWidget(btn_r)

        btn_d = QPushButton("Delete", self)
        btn_d.clicked.connect(self.do_delete)
        layout.addWidget(btn_d)

    def popup_offset(self):
        return self.pos() + QPoint(20, 10)

    def do_rename(self):
        input_dlg = QInputDialog(self)
        input_dlg.setWindowTitle("Rename")
        input_dlg.setLabelText("Nyt navn:")
        input_dlg.setWindowFlags(input_dlg.windowFlags() | Qt.WindowStaysOnTopHint)
        input_dlg.move(self.popup_offset())
        input_dlg.activateWindow()
        input_dlg.raise_()

        if input_dlg.exec_():
            name = input_dlg.textValue().strip()
            if name:
                new = rename_latest_recording(name, self.source_dir, "mp4")
                if new:
                    msgbox = QMessageBox(self)
                    msgbox.setWindowTitle("Rename")
                    msgbox.setText(f"Renamed to:\n{os.path.basename(new)}")
                    msgbox.setWindowFlags(msgbox.windowFlags() | Qt.WindowStaysOnTopHint)
                    msgbox.move(self.popup_offset())
                    msgbox.exec_()
        self.close()

    def do_delete(self):
        ok, msg = delete_latest_recording(self.source_dir, "mp4")
        msgbox = QMessageBox(self)
        msgbox.setWindowTitle("Delete")
        msgbox.setText(msg)
        msgbox.setWindowFlags(msgbox.windowFlags() | Qt.WindowStaysOnTopHint)
        msgbox.move(self.popup_offset())
        msgbox.exec_()
        self.deleted = ok
        self.close()

    def closeEvent(self, ev):
        if not self.deleted:
            self._process_in_background()
        ev.accept()

    def _process_in_background(self):
        self.status_callback("Konverterer & gemmer…")

        worker = Worker(self.source_dir, self.nextcloud_dir)
        worker.finished.connect(self.status_callback)
        worker.error.connect(lambda msg: self.status_callback(f"⚠ {msg}"))

        t = threading.Thread(target=worker.run, daemon=True)
        t.start()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.client    = None
        self.recording = False
        self.src       = r"C:\sange"
        self.dst       = r"C:\Users\jonas\Nextcloud\Sange"
        self.initUI()

    def initUI(self):
        self.resize(250, 125)
        self.setWindowTitle("OBS Audio Recorder")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        w = QWidget(self)
        self.setCentralWidget(w)
        v = QVBoxLayout(w)

        btn = QPushButton("Start Recording", self)
        btn.clicked.connect(self.toggle_rec)
        v.addWidget(btn)
        self.toggle_btn = btn

        self.status = QStatusBar(self)
        self.setStatusBar(self.status)

    def set_status(self, msg):
        self.status.showMessage(msg)

    def toggle_rec(self):
        if not self.client:
            try:
                self.client = obswebsocket.obsws("localhost", 4444, "")
                self.client.connect()
                self.set_status("Connected")
            except Exception as e:
                QMessageBox.critical(self, "Conn Error", str(e))
                return

        if not self.recording:
            self.client.call(obswebsocket.requests.StartRecording())
            self.toggle_btn.setText("Stop Recording")
            self.set_status("Recording…")
            self.recording = True
        else:
            self.client.call(obswebsocket.requests.StopRecording())
            self.toggle_btn.setText("Start Recording")
            self.set_status("Stopped")
            self.recording = False

            btn_pos = self.toggle_btn.mapToGlobal(self.toggle_btn.rect().topLeft()) + QPoint(20, 10)
            dlg = RenameOrDeleteDialog(self.src, self.dst, self.set_status)
            dlg.move(btn_pos)
            dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowStaysOnTopHint)
            dlg.show()
            dlg.activateWindow()
            dlg.raise_()
            dlg.exec_()


def main():
    app = QApplication(sys.argv)
    mw  = MainWindow()
    mw.show()
    mw.activateWindow()
    mw.raise_()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
